% Buffon's needle experiment to calculate the probability of a randomly
% thrown needle crossing a line on a table with lines separated by a
% distance which is equal to the length of the needle
% 
% Sinan Yildirim, 27.09.2016

% clear all the variables, clear the command line, close all the figures
clear all; clc; close all;

% sample size
N = 10000;

% initialise arrays:
d = zeros(1, N);
theta = zeros(1, N);
c = zeros(1, N);

% Start the experiment
for i = 1:N
    % Throw the needle i'th time: generate the distance and the angle:
    % rand generates a uniform random number in (0, 1)
    d(i) = 0.5*rand;
    theta(i) = (pi/2)*rand;
    
    % check if the needle crosses a line
    if d(i) < sin(theta(i))/2
        c(i) = 1; % the needle crossed a line
    end
end

% estimate the probability of cross
prob_cross_est = sum(c)/N;
% estimate pi
pi_est = 2/prob_cross_est;


% report the results:
% print the results on the commnad line
fprintf('Buffon''s needle experiment with %d samples: \n', N);
fprintf('The estimated and true probabilities are %.4f and %.4f \n',...
    prob_cross_est, 2/pi);
fprintf('The estimated and true value of pi is %.4f and %4f. \n',...
    pi_est, pi);
function l_sum = log_sum(v, dim)

% l_sum = log_sum(v, dim)
%
% This function calculates the logarithm of the sum of the numbers whose
% logarithms are given in the vector v in a stable way. It does the
% summation by extracting the maximum of the numbers' logarithms so that
% the arguement of the exponential function is small enough to be safe.
% 
% If v is a matrix, the function returns a row whose i'th element is
% log(sum(exp(column_i)))
%
% Sinan Yildirim, 09.11.2009
% Last update: 25.05.2014, 17.43

% get the size of the matrix

[a, b] = size(v);
if nargin == 1    
    if a == 1
        v = v(:);
        [a, b] = size(v);
    end
elseif nargin == 2
    if dim == 2
        v = v';
        [a, b] = size(v);    
    end
end

% find the maximum of each column and select the ones where the maximum is
% larger than -inf
m = max(v, [], 1);
I_red = m > -inf;
v_red = v(:, I_red);
m_red = m(I_red);

% perform log(sum(exp(.))) for the columns whose maximum element is larger
% than -inf
m_red_rep = repmat(m_red, a, 1);
l_sum_red = log(sum(exp(v_red - m_red_rep), 1)) + m_red;

% finally, costruct the output vector by filling the rest 
l_sum = -inf*ones(1, b);
l_sum(I_red) = l_sum_red;

if nargin == 2
    if dim == 2
        l_sum = l_sum';    
    end
end

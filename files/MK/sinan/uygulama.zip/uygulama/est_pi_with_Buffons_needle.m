% Buffon's needle experiment to approximate pi.
%
% This code is used to generate Figure 1.5 of the main document
% 
% Sinan Yildirim, 27.09.2016
clear all; clc; close all; fc = 0;

% The vector of sample sizes with which the estimate of pi is calculated
N_vec = 10:10:10000;
L_n  = length(N_vec);

pi_est = zeros(1, L_n);
for i = 1:L_n
    N = N_vec(i);
    % Run Buffon's needle experiment
    d = 0.5*rand(1, N);
    theta = (pi/2)*rand(1, N);
    cross_prob_est = sum(d < sin(theta)/2)/N;
    pi_est(i) = 2/cross_prob_est;
end
    
% plot the result
plot(N_vec, pi_est);
xlabel('N'); ylabel('estimate of \pi');
hold on;
plot(N_vec, pi*ones(1, L_n), 'r');
hold off;
title('Buffon''s needle experiment to approximate \pi');
function [DJ] = ooy(x, y, theta, method)
% Ornek Ortalamasi Yaklasimi
x = x';
N = length(y);
[C, n] = size(theta);

DJ = zeros(C, n);

if strcmp(method, 'ygi') % Yigin Gradyant Inis
    for j=1:C
        for k=1:N
            denom = 0;
            for l=1:C
                denom = denom + exp(theta(l, :)*x(:, k));
            end
            num = exp(theta(j, :)*x(:, k));
            if (y(k)==j)
                DJ(j, :) = DJ(j, :) - (1/N)*((x(k)*(1 - (num/denom))));
            else
                DJ(j, :) = DJ(j, :) - (1/N)*((x(k)*(0 - (num/denom))));
            end
        end
    end % j
elseif strcmp(method, 'rgi') % Rassal Gradyant Inis
    for j=1:C
        k = randperm(N, 1);
        denom = 0;
        for l=1:C
            denom = denom + exp(theta(l, :)*x(:, k));
        end
        num = exp(theta(j, :)*x(:, k));
        if (y(k)==j)
            DJ(j, :) = DJ(j, :) - ((x(k)*(1 - (num/denom))));
        else
            DJ(j, :) = DJ(j, :) - ((x(k)*(0 - (num/denom))));
        end
    end % j
end

end % Function end


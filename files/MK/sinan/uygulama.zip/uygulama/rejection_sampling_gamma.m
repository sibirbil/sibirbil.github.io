% rejection sampling for the gamma distribution using exponential
% distribution as the instrumental distribution.
%
% This code is used to generate Figure 2.4 of the main document.
% 
% Sinan Yildirim, 06.10.2016

clear all; clc; close all; fc = 0;
alpha = 2;
lambda_opt = 1/alpha;
M_opt = alpha^alpha*exp(-alpha + 1)/gamma(alpha);

% try with a suboptimal lambda
lambda_0 = 0.01;
M_0 = ((alpha - 1)/(1 - lambda_0))^(alpha - 1)*exp(-alpha + 1)...
        /(lambda_0*gamma(alpha));

% Number of trials:
T = 100000;
X_opt = zeros(1, T);
X_0 = zeros(1, T);
% these count the number of accepted (generated) samples
N_opt = 0;
N_0 = 0;

% perform rejection sampling M times
for t = 1:T
    % optimum 
    x_prop = exprnd(1/lambda_opt);
    ratio = x_prop^(alpha-1)*exp((lambda_opt - 1)*x_prop)...
            *((1-lambda_opt)/(alpha-1))^(alpha - 1)*exp(alpha - 1);        
    if rand < ratio
        N_opt = N_opt + 1;
        X_opt(N_opt) = x_prop;
    end
    
    % suboptimum
    x_prop = exprnd(1/lambda_0);
    ratio = x_prop^(alpha-1)*exp((lambda_0 - 1)*x_prop)...
            *((1-lambda_0)/(alpha-1))^(alpha - 1)*exp(alpha - 1);
    if rand < ratio;
        N_0 = N_0 + 1;
        X_0(N_0) = x_prop;
    end
end
% Keep the filled parts of the arrays
X_opt = X_opt(1:N_opt);
X_0 = X_0(1:N_0);

% report the results:
fprintf('Number of samples generated out of %d trials: \n', T);
fprintf('using lambda = %.2f: %d \n', lambda_opt, N_opt);
fprintf('using lambda = %.2f: %d \n', lambda_0, N_0);

fc = fc + 1; figure(fc);
subplot(1, 2, 1);
hist(X_opt, 50);
xlabel('x');
ylabel('frequency');
title('histogram of samples generated using \lambda = 0.5');

subplot(1, 2, 2);
hist(X_0, 50);
xlabel('x');
title('histogram of samples generated using \lambda = 0.01');


    
% method of inversion.
% 
% This code is used to generate Figures 2.1 and 2.2 of the main document
% 
% Sinan Yildirim, 06.10.2016

clear all; clc; close all; fc = 0;

% exponential pdf
lambda = 1;

% x axis
x = 0:0.001:10;
% calculate the pdf
pdf_x = lambda*exp(-lambda*x);
% calculate the cdf;
cdf_x = 1 - exp(-lambda*x);

fc = fc + 1; figure(fc);
plot(x, pdf_x, x, cdf_x);hold on;
loc = 1200;
plot(x(loc)*ones(1, 10), linspace(0, cdf_x(loc), 10), '--k');
plot(linspace(0, x(loc), 10), cdf_x(loc)*ones(1, 10), '--k');
text(x(loc), -0.1, 'G(u)');
text(-0.25,cdf_x(loc),'u');

hold off;
title('exponential distribution: sampling via the method of inversion');
legend('pdf', 'cdf');
xlabel('x');
set(gca, 'ylim', [0, 1.2]);

% geometric distribution
x = 0:10;
rho = 0.3;
% calculate the pmf
pmf_x = (1 - rho).^x*rho;
% calculate the cdf;
cdf_x = 1 - (1 - rho).^(x+1);

fc = fc + 1; figure(fc);
stem(x, pmf_x, '*');
hold on;
for i = 1:length(x)-1
    plot(linspace(x(i), x(i+1), 2), cdf_x(i)*ones(1, 2), 'k', 'linewidth', 2);
end
legend('pmf', 'cdf');
plot(x, cdf_x, '.k' ,'markersize', 25);
scatter(x, [0 cdf_x(1:end-1)], 'ok');
xlabel('x');
set(gca, 'ylim', [0, 1.2]);
title('Geo(0.3): sampling via the method of inversion');

% show an example for the method of inversion
g_u = 3;
u = 0.7;
plot(g_u*ones(1, 40), linspace(0, u, 40), '.k');
plot(linspace(0, 3, 40), u*ones(1, 40), '.k');
text(g_u, -0.1, 'G(u)');
text(-0.25, u,'u');
hold off;
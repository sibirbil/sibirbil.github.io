 ## Imports

from pyspark import SparkConf, SparkContext
import random 

## CONSTANTS

APP_NAME = "Kamer's Sparky Pi"
NUM_SAMPLES = 10000000

def sample(k):
    x = random.random()
    y = random.random()
    return 1 if (x*x) + (y*y) <= 1 else 0

if __name__ == "__main__":
     # Configure OPTIONS
     conf = SparkConf().setAppName(APP_NAME)
     conf = conf.setMaster("local[1]")
     #in cluster this will be like
     #"spark://ec2-0-17-03-078.compute-#1.amazonaws.com:7077"
     sc   = SparkContext(conf=conf)
     # Execute Main functionality

count = sc.parallelize(xrange(0, NUM_SAMPLES)).map(sample) \
    .reduce(lambda a, b: a + b)
print("Pi is roughly %f" % (4.0 * count / NUM_SAMPLES))


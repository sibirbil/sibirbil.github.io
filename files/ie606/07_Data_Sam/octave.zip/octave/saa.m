function [DJ] = saa(x, y, theta, method)
x = x';
N = length(y);
[C, n] = size(theta);

DJ = zeros(C, n);

if strcmp(method, 'bgd')
    for k=1:N
        denom = 0;
        for j=1:C
            for l=1:C
                if l == j
                    num = exp(theta(l, :)*x(:, k));
                end
                denom = denom + exp(theta(l, :)*x(:, k));
            end
            if (y(k)==j)
                DJ(j, :) = DJ(j, :) - ((1/N)*(x(k)*(1 - (num/denom))));
            else
                DJ(j, :) = DJ(j, :) - ((1/N)*(x(k)*(0 - (num/denom))));
            end
        end
    end
elseif strcmp(method, 'sgd')
        k = randperm(N, 1);
        denom = 0;
        for j=1:C
            for l=1:C
                if l == j
                    num = exp(theta(l, :)*x(:, k));
                end
                denom = denom + exp(theta(l, :)*x(:, k));
            end
            if (y(k)==j)
                DJ(j, :) = DJ(j, :) - ((x(k)*(1 - (num/denom))));
            else
                DJ(j, :) = DJ(j, :) - ((x(k)*(0 - (num/denom))));
            end
        end
end

end % Function end


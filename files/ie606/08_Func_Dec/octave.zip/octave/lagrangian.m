function [f, g] = lagrangian(x, lambda, U, u, A, b)

    f = (0.5*norm(U - u*x')^2) + lambda'*(A*x - b);
    g = (U - u*x')'*u + A'*lambda;

end % Function end


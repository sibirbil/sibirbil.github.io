% source localisation sequential (target tracking) 
% 
% Sinan Yildirim, 19.10.2016

clear all; clc; close all; fc = 0;

% parameters
mu_b = [0 0]; var_vb = 0.01; var_xb = 4; a = 0.95; var_v = 0.01; var_y = 10;

% Locations of the sensors
S1 = [0 20]'; S2 = [-20 -10]'; S3 = [10 -20]';

% time length
n = 1000;

% generate the data 
V = zeros(2, n);
P = zeros(2, n);
Y = zeros(3, n);

for t = 1:n
    % move the location of the target
    if t == 1
        V(:, 1) = sqrt(var_vb)*randn(2, 1);
        P(:, 1) = sqrt(var_xb)*randn(2, 1);
    else
        V(:, t) = a*V(:, t-1) + sqrt(var_v)*randn(2, 1);
        P(:, t) = P(:, t-1) + V(:, t-1);
    end
    % generate the observation
    Y(1, t) = randn*sqrt(var_y) + norm(P(:, t) - S1);
    Y(2, t) = randn*sqrt(var_y) + norm(P(:, t) - S2);
    Y(3, t) = randn*sqrt(var_y) + norm(P(:, t) - S3);
end

%% Particle filter for target tracking

N = 1000;
log_w = zeros(1, N);

P_est = zeros(2, n);

for t = 1:n
    if t == 1
        V_par = sqrt(var_vb)*randn(2, N);
        P_par = sqrt(var_xb)*randn(2, N);
    else
        % resample:
        [res_ind] = resample(w_norm, 'multinomial');
        V_par_res = V_par(:, res_ind);
        P_par_res = P_par(:, res_ind);
        
        % propogate the particles
        V_par = a*V_par_res + sqrt(var_v)*randn(2, N);
        P_par = P_par_res + V_par_res;
    end
    
    % calculate the weights:
    for i = 1:N
        R = [norm(P_par(:, i) - S1) norm(P_par(:, i) - S2)...
            norm(P_par(:, i) - S3)]';
        log_w(i) = -0.5*sum((Y(:, t) - R).^2) - 1.5*log(2*pi*var_y);
    end
    
    w_norm = exp(log_w - log_sum(log_w));
    
    P_est(:, t) = [sum(P_par(1, :).*w_norm); sum(P_par(2, :).*w_norm)];

end

% visualise the data and the results
for t = 1:n
    subplot(1,2,1);
    plot(P(1, t), P(2, t), '*k');
    hold on;
    plot(P_est(1, t), P_est(2, t), '*r');
    
    subplot(1,2,2);
    plot(repmat((t)', 1, 1), Y(1, t)', '.k');
    plot(repmat((t)', 1, 1), Y(2, t)', '.r');
    plot(repmat((t)', 1, 1), Y(3, t)', '.b');
    hold on;
    drawnow;
    
end 
subplot(1,2,1);
hold off;
title('path for the target position for 1000 time steps');
xlabel('P_{t}(1)'); 
ylabel('P_{t}(2)');
subplot(1,2,2);
title('noisy sensor measurements');
xlabel('t');
hold off;

% importance sampling for a Bayesian inference problem
% 
% This code is used to generate Figure 3.1 and Figure 3.2 of the 
% main document.
% 
% Sinan Yildirim, 14.10.2016

clear all; clc; close all; fc = 0;

% parameters:
mu_x = 0; var_x = 20;
a = 0.5;
% Generate X
X = sqrt(var_x)*randn + mu_x;

n = 10;
% Generate Y
Y = X + 2*a*(rand(1, n) - 0.5);
Y_min = min(Y); 
Y_max = max(Y);

% plot the prior and joint = prior x likelihood
x = -20:0.01:20;
p_x = normpdf(x, mu_x, sqrt(var_x));
l_x = ((x < (Y_min+a)) & (x > (Y_max - a)))/(2*a)^n;


fc = fc+1; figure(fc);
subplot(1,2,1);
plot(x, p_x);
hold on;
plot(Y, zeros(1, n), '*r');
hold off;
title('p_{X}(x)');
xlabel('x');
legend('p_{X}(x)', 'y_{1}, ..., y_{10}');

subplot(1, 2, 2);
plot(x, p_x.*l_x);
set(gca, 'xlim', [X-a, X+a]);
hold on;
plot(Y, zeros(1, n), '*r');
hold off;

title('p_{X, Y}(x, y) = p_{X}(x)p_{Y |X}(y | x)');
xlabel('x');
legend('p_{X, Y}(x, y)', 'y_{1}, ..., y_{10}');


% importance samlpling
% number of Monte Carlo runs
M = 10000;

% number of samples to be used in each run
N = 1000;

est_post_mean_1 = zeros(1, M);
est_post_mean_2 = zeros(1, M);

for m = 1:M
    % 1. importance sampling when the importance distribution is the prior
    X_samp_1 = sqrt(var_x)*randn(1, N) + mu_x;
    W_1 = ((X_samp_1 < (Y_min+a)) & (X_samp_1 > (Y_max - a)));
    % self normalised importance sampling estimator for the posterior mean
    est_post_mean_1(m) = sum(X_samp_1.*W_1)/sum(W_1);
    
    % 2. importance sampling when the importance distribution is the
    % uniform distribution between Y_max - a and Y_min + a.
    X_samp_2 = (2*a + Y_min - Y_max)*rand(1, N) + Y_max - a;
    W_2 = normpdf(X_samp_2, mu_x, var_x);
    % self normalised importance sampling estimator for the posterior mean
    est_post_mean_2(m) = sum(X_samp_2.*W_2)/sum(W_2);
    
end

fc = fc + 1; figure(fc);
subplot(1, 2, 1);
hist(est_post_mean_1, 50);
title(sprintf('importance distribution is prior: variance: %.5f', var(est_post_mean_1)));
xlabel('estimated posterior mean');
subplot(1, 2, 2);
hist(est_post_mean_2, 50);
title(sprintf('importance distribution is uniform: variance: %.5f', var(est_post_mean_2)));
xlabel('estimated posterior mean');



% Source localisation problem
% 
% This code is used to generate Figures 3.3 and 3.4 of the main document
% 
% Sinan Yildirim, 16.10.2016

clear all; clc; close all; fc = 0;

% unknown location of X
X = [-0.5 0];

% Locations of the sensors
S1 = [0 2]; S2 = [-2 -1]; S3 = [1 -2];

% std of the measurement noise in each coordinate
sigma_y = 1;

% plot the source and measurements
fc = fc + 1; figure(fc);
plot(X(1), X(2), 's', 'markersize', 20, 'markerfacecolor', 'b');
hold on;
plot([S1(1) S2(1) S3(1)], [S1(2) S2(2) S3(2)], 'ko', 'markersize', 10);
plot(linspace(X(1), S1(1), 2), linspace(X(2), S1(2), 2), '--');
plot(linspace(X(1), S2(1), 2), linspace(X(2), S2(2), 2), '--');
plot(linspace(X(1), S3(1), 2), linspace(X(2), S3(2), 2), '--');
set(gca, 'xlim', [-3, 3], 'ylim', [-3, 3]);
eps_text = 0.25;
text(X(1)+eps_text, X(2), 'source');
text(S1(1)+eps_text, S1(2), 'sensor 1');
text(S2(1)+eps_text, S2(2), 'sensor 2');
text(S3(1)+eps_text, S3(2), 'sensor 3');
text((S1(1)+X(1))/2 + eps_text/2, (S1(2) + X(2))/2, 'r_{1}');
text((S2(1)+X(1))/2 + eps_text/2, (S2(2) + X(2))/2, 'r_{2}');
text((S3(1)+X(1))/2 + eps_text/2, (S3(2) + X(2))/2, 'r_{3}');
hold off;
xlabel('x(1)'); ylabel('x(2)');


% plot the likelihood and prior for x
y1 = 2; y2 = 1.6; y3 = 2.5; var_x = 100; var_y = 1;

x1_axis = -6:0.01:6; x2_axis = -6:0.01:6;
L_x1 = length(x1_axis); L_x2 = length(x2_axis);

log_lkl_1 = zeros(L_x1, L_x2);
log_lkl_2 = zeros(L_x1, L_x2);
log_lkl_3 = zeros(L_x1, L_x2);
log_prior = zeros(L_x1, L_x2);

for i = 1:L_x1
    for j = 1:L_x2
        r1 = sqrt((x1_axis(i) - S1(1))^2 + (x2_axis(j) - S1(2))^2);
        r2 = sqrt((x1_axis(i) - S2(1))^2 + (x2_axis(j) - S2(2))^2);
        r3 = sqrt((x1_axis(i) - S3(1))^2 + (x2_axis(j) - S3(2))^2);
        
        log_lkl_1(i, j) = -(y1 - r1)^2/(2*var_y) - log(2*pi*var_y);
        log_lkl_2(i, j) = -(y2 - r2)^2/(2*var_y) - log(2*pi*var_y);
        log_lkl_3(i, j) = -(y3 - r3)^2/(2*var_y) - log(2*pi*var_y);
        
        log_prior(i, j) = -(x1_axis(i)^2 + x2_axis(j)^2)/(2*var_x)...
            - 2*log(2*pi*var_x);
    end
end
fc = fc + 1; figure(fc);
subplot(2, 3, 1);
colormap(hot);
imagesc(x1_axis, x2_axis, exp(log_lkl_1));% colormap(default); % colorbar;
xlabel('x(2)'); ylabel('x(1)'); title('Likelihood term p(y_{1} | x)');
subplot(2, 3, 2);
imagesc(x1_axis, x2_axis, exp(log_lkl_2)); % colormap(winter); % colorbar;
xlabel('x(2)'); ylabel('x(1)'); title('Likelihood term  p(y_{2} | x)');
subplot(2, 3, 3);
imagesc(x1_axis, x2_axis, exp(log_lkl_3)); % colormap(winter); colorbar;
xlabel('x(2)'); ylabel('x(1)'); title('Likelihood term p(y_{3} | x)');
subplot(2, 3, 4);
imagesc(x1_axis, x2_axis, exp(log_prior));
xlabel('x(2)'); ylabel('x(1)'); title('Prior p_{X}(x)');
subplot(2, 3, 5);
imagesc(x1_axis, x2_axis, exp(log_prior).*exp(log_lkl_1).*exp(log_lkl_2).*exp(log_lkl_3));
xlabel('x(2)'); ylabel('x(1)'); title('posterior \propto prior x likelihood');
set(gca,'xlim', [-3, 3]); set(gca,'ylim', [-3, 3]);
colorbar;

y = [y1 y2 y3];

%% Metropolis-Hastings for the posterior

% initial value:
X_init = [5 5];

M = 10000;
X_samp = zeros(M, 2);

% variance of the proposal distribution in each direction
var_q = 0.01;

x = X_init;
X_samp(1, :) = x;
r_curr_1 = sqrt((x(1) - S1(1))^2 + (x(2) - S1(2))^2);
r_curr_2 = sqrt((x(1) - S2(1))^2 + (x(2) - S2(2))^2);
r_curr_3 = sqrt((x(1) - S3(1))^2 + (x(2) - S3(2))^2);
r_curr = [r_curr_1 r_curr_2 r_curr_3];
    
for m = 2:M
    % propose the next sample
    x_prop = x + randn(1, 2)*sqrt(var_q);
    
    % calculate the log acceptance probability:
    r_prop_1 = sqrt((x_prop(1) - S1(1))^2 + (x_prop(2) - S1(2))^2);
    r_prop_2 = sqrt((x_prop(1) - S2(1))^2 + (x_prop(2) - S2(2))^2);
    r_prop_3 = sqrt((x_prop(1) - S3(1))^2 + (x_prop(2) - S3(2))^2);
    r_prop = [r_prop_1 r_prop_2 r_prop_3];
    
    % log-likelihoods
    log_l_prop = sum(-(y - r_prop).^2/(2*var_y) - log(2*pi*var_y));
    log_l_curr = sum(-(y - r_curr).^2/(2*var_y) - log(2*pi*var_y));
    
    % log priors
    log_p_prop = -(x_prop(1)^2 + x_prop(2)^2)/(2*var_x) - 2*log(2*pi*var_x);
    log_p_curr = -(x(1)^2 + x(2)^2)/(2*var_x) - 2*log(2*pi*var_x);
        
    log_r = log_l_prop + log_p_prop - (log_l_curr + log_p_curr);
    
    % decision
    decision = (rand < exp(log_r));
    
    % determine the sample
    x = decision*x_prop + (1 - decision)*x;
    r_curr = decision*r_prop + (1 - decision)*r_curr;
    
    % store the samples
    X_samp(m, :) = x;
end

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
plot(X_samp(:, 1), 'k');
xlabel('iterations');
ylabel('X_{t}(1)');
title('Samples for X(1)');
subplot(2, 2, 2);
plot(X_samp(:, 2), 'k');
xlabel('iterations');
ylabel('X_{t}(2)');
title('Samples for X(2)');

subplot(2, 2, 3);
hist(X_samp(:, 1), 50);
xlabel('x');
title('Histogram of samples for X(1)');
subplot(2, 2, 4);
hist(X_samp(:, 2), 50);
xlabel('x');
title('Histogram of samples for X(2)');

fc = fc + 1; figure(fc);
imagesc(x1_axis, x2_axis, exp(log_prior).*exp(log_lkl_1).*exp(log_lkl_2).*exp(log_lkl_3));
xlabel('x(2)'); ylabel('x(1)'); title('first 200 samples');
hold on;
plot(X_samp(1:200, 2), X_samp(1:200, 1), 'o-');
set(gca,'xlim', [-6, 6]); set(gca,'ylim', [-6, 6]);
hold off;
colormap(gray);

%% Importance sampling for the posterior mean
% number of trials
T = 1000;
X_1_post = zeros(1, T);
X_2_post = zeros(1, T);

% number of samples:
N = 10000;

for t = 1:T
    
    if mod(t, 100) == 0
        disp(t);
    end
    % sample from the prior
    X_samp = sqrt(var_x)*randn(2, N);

    log_w = zeros(1, N);
    % compute the weights
    for i = 1:N
        % calculate the log acceptance probability:
        r_samp_1 = sqrt((X_samp(1, i) - S1(1))^2 + (X_samp(2, i) - S1(2))^2);
        r_samp_2 = sqrt((X_samp(1, i) - S2(1))^2 + (X_samp(2, i) - S2(2))^2);
        r_samp_3 = sqrt((X_samp(1, i) - S3(1))^2 + (X_samp(2, i) - S3(2))^2);

        r_samp = [r_samp_1 r_samp_2 r_samp_3];

        % log-likelihoods
        log_w(i)= sum(-(y - r_samp).^2/(2*var_y) - log(2*pi*var_y)); 
    end

    % normalise the weights
    w_norm = exp(log_w - log_sum(log_w));

    % calcalate the posterior mean estimates
    X_1_post(t) = sum(X_samp(1, :).*w_norm);
    X_2_post(t) = sum(X_samp(2, :).*w_norm);
    
end

fc = fc + 1; figure(fc);
subplot(1, 2, 1);
hist(X_1_post, 50);
xlabel('estimated values');
title(sprintf('histogram of %d importance sampling estimates for E(X(1) | y)', T));
subplot(1, 2, 2);
hist(X_2_post, 50);
xlabel('estimated values');
title(sprintf('histogram of %d importance sampling estimates for E(X(2) | y)', T));

%% Rejection sampling for exact samples and posterior mean
log_M_r = -1.5*log(2*pi*var_y)^1.5;

% number of trials
T = 1000;
X_1_post = zeros(1, T);
X_2_post = zeros(1, T);
C = zeros(1, T);

% number of iterations for rejection sampling:
N = 10000;

for t = 1:T

    if mod(t, 100) == 0
        disp(t);
    end
    
    % sample from the prior
    X_prop = sqrt(var_x)*randn(2, N);
        
    % count the number of samples to be estimated
    c = 0;
    X_samp = zeros(2, N);
    for i = 1:N
        % calculate the log acceptance probability:
        
        r_prop_1 = sqrt((X_prop(1, i) - S1(1))^2 + (X_prop(2, i) - S1(2))^2);
        r_prop_2 = sqrt((X_prop(1, i) - S2(1))^2 + (X_prop(2, i) - S2(2))^2);
        r_prop_3 = sqrt((X_prop(1, i) - S3(1))^2 + (X_prop(2, i) - S3(2))^2);

        r_prop = [r_prop_1 r_prop_2 r_prop_3];

        % log-likelihoods
        log_w(i)= sum(-(y - r_prop).^2/(2*var_y) - log(2*pi*var_y)); 
        
        % acceptance probability
        accept_prop = exp(log_w(i) - log_M_r);
        
        if rand < accept_prop
            c = c + 1;
            X_samp(:, c) = X_prop(:, i);
        end
    end
    C(t) = c;
    X_samp = X_samp(:, 1:c);

    % calcalate the posterior mean estimates
    X_1_post(t) = mean(X_samp(1, :));
    X_2_post(t) = mean(X_samp(2, :));
    
end

fc = fc + 1; figure(fc);
subplot(2, 2, 1);
hist(X_1_post, 50);
xlabel('estimated values');
title(sprintf('hist of %d rej samp estimates for E(X(1) | y)', T));
subplot(2, 2, 2);
hist(X_2_post, 50);
xlabel('estimated values');
title(sprintf('hist of %d rej samp estimates for E(X(2) | y)', T));
subplot(2, 1, 2);
[a, b] = hist(C, 1:30);
stem(b, a);
xlabel('number of accepted samples');
title(sprintf('histogram of number of samples out of 10000 iterations', T));


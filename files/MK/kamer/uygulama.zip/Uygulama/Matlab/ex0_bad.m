% --------
% Non-integer loop indices
z = 0;
parfor x = 0:0.1:1
    z = z + x;
end

% Copyright 2010 - 2014 The MathWorks, Inc.
function [f, g] = auglagrangian(x, lambda, U, u, A, b, rho)

    f = (0.5*norm(U - u*x')^2) + lambda'*(A*x - b) + norm(A*x - b)^2;
    g = (U - u*x')'*u + A'*lambda + rho*A'*(A*x);

end % Function end


function drawfr(A, b)

% Graphs of the feasible region
% !! Best with bounded regions !!
% Ax <= b
%  x >= 0
% If the very last constraint is a cut
% then shows the cut explicitly


[m , n] = size(A);
rel = repmat('<', 1, m);
if (n ~= 2)
    str = 'Number of the legitimate variables must be equal to 2';
    msgbox(str, 'Error Window', 'error');
    return
end
t = extrpts(A,rel,b);
if (isempty(t))
    fprintf('\n Empty feasible region');
    return
end
t = t(1:2,:);
t = delcols(t);
d = extrdir(A,rel,b);
if ~isempty(d)
    msgbox('Unbounded feasible region','Warning Window','warn');
    fprintf('\n   Extreme direction(s) of the constraint set');
    fprintf('\n   Extreme points of the constraint set');
    return
end
t1 = t(1,:);
t2 = t(2,:);
z = convhull(t1,t2);
hold on
patch(t1(z),t2(z),'r', 'FaceAlpha', 0.1, 'EdgeColor', 'r', 'EdgeAlpha', 0.5)
h = .25;
mit1 = min(t1)-h;
mat1 = max(t1)+h;
mit2 = min(t2)-h;
mat2 = max(t2)+h;

% intx = (ceil(mit1):floor(mat1))';
% inty = (ceil(mit2):floor(mat2))';
% lx = length(intx);
% ly = length(inty);
% intx = repmat(intx, ly, 1);
% inty = repmat(inty, 1, lx);
% inty = reshape(inty', lx*ly, 1);
% plot(intx, inty, 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'blue');


axis([mit1 mat1 mit2 mat2]);



xlabel('x_1');
h = get(gca,'xlabel');
set(h,'FontSize',11)
ylabel('x_2');
h = get(gca,'ylabel');
set(h,'FontSize',11)
grid on
hold on

